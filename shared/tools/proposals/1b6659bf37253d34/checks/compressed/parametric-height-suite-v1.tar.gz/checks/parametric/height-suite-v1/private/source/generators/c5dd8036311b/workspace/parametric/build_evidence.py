#!/usr/bin/env python3
"""Materialize and execute a reusable, private/public height-variant suite."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from typing import Any

from arc_repl.racket_bridge import RacketBridge
from reviewer_support import canonical_pairs, find_root

from prototype import (
    PARAMETER_SPEC, PROTOTYPE_VERSION, TASK_ID, Parameters, all_parameters,
    build_input, canonical_program, check_identifiability, choose_parameters,
    execute, make_episode, public_challenge, racket_program, sha256,
)


LIMITATIONS = [
    "Proposed task-local prototype; no production parametric interface or approval change.",
    "Parameters are heights 2..5 only; background, direction, marker colors, and stem color stay fixed.",
    "Generated inputs contain a full-width bar, both marker types, no distractors, and complete columns.",
    "All 16 parameter rivals are checked; arbitrary alternative algorithms are outside this finite check.",
    "Holdout rotation means choosing each existing pair as the query; it is not geometric rotation.",
    "The input builder is intentionally independent of the hidden setting and reserves five rows above the bar.",
]


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def find_seeds(start: int, count: int) -> dict[Parameters, list[int]]:
    selected = {p: [] for p in all_parameters()}
    for seed in range(start, start + 100_000):
        p = choose_parameters(seed)
        if len(selected[p]) < count:
            selected[p].append(seed)
        if all(len(values) == count for values in selected.values()):
            return selected
    raise RuntimeError("bounded seed search could not cover every setting")


def predictions_for(bridge: RacketBridge, programs: dict[Parameters, str],
                    pairs: list[dict[str, Any]]) -> dict[Parameters, list[list[list[int]]]]:
    return {p: [execute(bridge, source, pair["input"]) for pair in pairs]
            for p, source in programs.items()}


def save_identifiability(path: Path, pairs: list[dict[str, Any]], selected: Parameters,
                         predictions: dict[Parameters, list[list[list[int]]]]) -> dict[str, Any]:
    report = check_identifiability(pairs, selected, predictions)
    write_json(path, {"selected_parameters": selected.as_dict(), "report": report,
                     "racket_predictions": {p.key(): outputs for p, outputs in predictions.items()}})
    return report


def source_manifest(root: Path, out: Path) -> dict[str, str]:
    folder = root / f"generators/{TASK_ID}/workspace/parametric"
    sources = [folder / name for name in ("prototype.py", "build_evidence.py", "README.md")]
    sources.append(root / f"generators/{TASK_ID}/tests/test_parametric_heights.py")
    result = {}
    for source in sources:
        relative = source.relative_to(root)
        snapshot = out / "private/source" / relative
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, snapshot)
        result[str(relative)] = sha256(source.read_bytes())
    return result


def build_suite(out: Path, *, seed_start: int = 0, episodes_per_setting: int = 2,
                n_train: int = 3) -> dict[str, Any]:
    if type(episodes_per_setting) is not int or not 1 <= episodes_per_setting <= 8:
        raise ValueError("episodes_per_setting must be in 1..8")
    if type(n_train) is not int or not 1 <= n_train <= 7:
        raise ValueError("n_train must be in 1..7")
    root = find_root(__file__)
    out = out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    timestamp = datetime.now(timezone.utc).isoformat()
    receipt = {
        "schema": "c5dd8036311b-parametric-evidence-v1",
        "status": "running",
        "prototype_status": "proposed",
        "task_id": TASK_ID,
        "prototype_version": PROTOTYPE_VERSION,
        "started_utc": timestamp,
        "command_argv": [sys.executable, *sys.argv],
        "cwd": str(Path.cwd()),
        "source_root": str(root),
        "sources_sha256": source_manifest(root, out),
        "python": sys.version,
        "racket_executable": os.environ.get("RACKET_PATH"),
        "seed_start": seed_start,
        "episodes_per_setting": episodes_per_setting,
        "demonstrations_per_episode": n_train,
        "limitations": LIMITATIONS,
    }
    runtime_binary = receipt["racket_executable"]
    if runtime_binary:
        version = subprocess.run([runtime_binary, "--version"], text=True, capture_output=True, check=False)
        receipt["racket_version"] = {"exit_code": version.returncode,
                                     "stdout": version.stdout, "stderr": version.stderr}
    dependencies = [
        "shared/runtime/reviewer_support.py",
        "shared/runtime/arc_repl/racket_bridge.py",
        "shared/runtime/arc_repl/racket_prelude/arc-prelude.rkt",
    ]
    receipt["runtime_sources_sha256"] = {
        path: sha256((root / path).read_bytes()) for path in dependencies if (root / path).is_file()
    }
    write_json(out / "manifest.json", receipt)
    try:
        programs = {p: racket_program(p, root=root) for p in all_parameters()}
        canonical = canonical_program(root)
        rules = {}
        for setting, program in programs.items():
            target = out / "private/rules" / f"{setting.key()}.rkt"
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(program, encoding="utf-8")
            rules[setting.key()] = {"parameters": setting.as_dict(),
                                    "program_sha256": sha256(program),
                                    "path": str(target.relative_to(out))}
        write_json(out / "private/specification.json", {
            "parameters": PARAMETER_SPEC,
            "default": Parameters().as_dict(),
            "sampling": "Both parameters are drawn once from a deterministic episode seed; all pairs share the result.",
            "input_constraints": "One full-width marked bar; other cells 0; complete columns; both marker colors in each generated pair; bar row at least 5, independent of chosen heights.",
            "invariant_reasoning": "Locate the bar and each marker, infer per-color height from demonstrations, grow upward at the same columns with the marker at the tip and color 1 beneath, preserve the input bar and every other cell.",
            "rules": rules,
        })
        seeds = find_seeds(seed_start, episodes_per_setting)
        episode_summaries = []
        with RacketBridge(timeout=10) as bridge:
            canonical_checks = []
            for pair in canonical_pairs(TASK_ID, root=root):
                actual = execute(bridge, programs[Parameters()], pair["input"])
                canonical_checks.append({**pair, "executed_default_output": actual,
                                         "matches_canonical_label": actual == pair["output"]})
            canonical_passed = all(pair["matches_canonical_label"] for pair in canonical_checks)
            if not canonical_passed:
                raise AssertionError("default Racket does not reproduce all canonical outputs")
            write_json(out / "private/canonical-default-check.json", {
                "default_program_is_exact_canonical_text": programs[Parameters()] == canonical,
                "canonical_program_sha256": sha256(canonical),
                "normalized_rule_hash": sha256(" ".join(canonical.split()))[:12],
                "all_pairs_passed": canonical_passed,
                "pair_count": len(canonical_checks),
                "pairs": canonical_checks,
            })
            index = 0
            for setting in all_parameters():
                for seed in seeds[setting]:
                    episode = make_episode(seed, bridge=bridge, root=root, n_train=n_train)
                    if episode["parameters"] != setting.as_dict():
                        raise AssertionError("seeded episode changed its selected setting")
                    name = f"episode-{index:03d}"
                    write_json(out / f"private/episodes/{name}.json", episode)
                    write_json(out / f"public/{name}.json", public_challenge(episode))
                    predictions = predictions_for(bridge, programs, episode["pairs"])
                    report = save_identifiability(out / f"private/identifiability/{name}.json",
                                                  episode["pairs"], setting, predictions)
                    if not report["identified_all_rotations"]:
                        raise AssertionError(f"{name}: ambiguous generated episode; evidence retained")
                    episode_summaries.append({
                        "episode_id": name, "seed": seed, "parameters": setting.as_dict(),
                        "program_sha256": episode["program_sha256"],
                        "pair_count": len(episode["pairs"]),
                        "query_holdouts_checked": len(report["rotations"]),
                        "identified_all_rotations": report["identified_all_rotations"],
                        "ambiguity_count": report["ambiguity_count"],
                    })
                    index += 1
                    if index % 8 == 0:
                        print(f"Verified {index}/{16 * episodes_per_setting} episodes", flush=True)
            # One common lawful input makes every distinct setting disagree.
            witness = build_input(seed_start, 0)
            witness_outputs = {p.key(): execute(bridge, source, witness) for p, source in programs.items()}
            distinct = len({json.dumps(output) for output in witness_outputs.values()})
            write_json(out / "private/setting-difference-witness.json", {
                "input": witness, "outputs": witness_outputs,
                "distinct_output_count": distinct, "expected_distinct_count": 16,
            })
            if distinct != 16:
                raise AssertionError("not every declared height setting changes executed behavior")
            # Negative control: no 8 markers in demos, 8 appears only in query.
            inputs = [build_input(seed_start, i) for i in range(3)]
            for grid in inputs[:2]:
                for row in grid:
                    for col, value in enumerate(row):
                        if value == 8:
                            row[col] = 1
            chosen = Parameters()
            pairs = [{"input": grid, "output": execute(bridge, programs[chosen], grid)} for grid in inputs]
            negative_predictions = predictions_for(bridge, programs, pairs)
            negative = save_identifiability(out / "private/negative-control-identifiability.json",
                                            pairs, chosen, negative_predictions)
            write_json(out / "private/negative-control-lesson.json", {
                "purpose": "Intentional diagnostic: omitted marker type must expose query ambiguity.",
                "parameters": chosen.as_dict(), "pairs": pairs,
            })
            last = negative["rotations"][-1]
            if len(last["surviving_settings"]) != 4 or len(last["query_ambiguities"]) != 3:
                raise AssertionError("ambiguity detector did not catch the undercovered negative control")
        receipt.update({
            "status": "completed", "exit_code": 0,
            "elapsed_seconds": round(time.monotonic() - started, 3),
            "setting_count": 16, "episode_count": len(episode_summaries),
            "pair_count": sum(row["pair_count"] for row in episode_summaries),
            "query_holdouts_checked": sum(row["query_holdouts_checked"] for row in episode_summaries),
            "parameter_rival_comparisons": 15 * sum(row["query_holdouts_checked"] for row in episode_summaries),
            "generated_episode_ambiguity_count": 0,
            "canonical_pair_count": len(canonical_checks),
            "default_canonical_parity": canonical_passed,
            "distinct_outputs_on_shared_witness": distinct,
            "negative_control_query_ambiguity_count": len(last["query_ambiguities"]),
            "episodes": episode_summaries,
        })
        files = {str(p.relative_to(out)): sha256(p.read_bytes())
                 for p in sorted(out.rglob("*")) if p.is_file() and p.name != "manifest.json"}
        receipt["files_sha256"] = files
        write_json(out / "manifest.json", receipt)
        return receipt
    except BaseException as exc:
        receipt.update({"status": "failed", "exit_code": 1,
                        "error": f"{type(exc).__name__}: {exc}",
                        "elapsed_seconds": round(time.monotonic() - started, 3)})
        write_json(out / "manifest.json", receipt)
        raise


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True, help="new evidence directory; existing paths are refused")
    parser.add_argument("--seed-start", type=int, default=0)
    parser.add_argument("--episodes-per-setting", type=int, default=2)
    parser.add_argument("--train", type=int, default=3, help="demonstration count per episode, 1..7")
    args = parser.parse_args()
    result = build_suite(args.out, seed_start=args.seed_start,
                         episodes_per_setting=args.episodes_per_setting, n_train=args.train)
    print(json.dumps({key: result[key] for key in (
        "status", "episode_count", "pair_count", "query_holdouts_checked",
        "default_canonical_parity", "generated_episode_ambiguity_count",
        "negative_control_query_ambiguity_count", "elapsed_seconds")}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
