# synthetic entry; never executed
