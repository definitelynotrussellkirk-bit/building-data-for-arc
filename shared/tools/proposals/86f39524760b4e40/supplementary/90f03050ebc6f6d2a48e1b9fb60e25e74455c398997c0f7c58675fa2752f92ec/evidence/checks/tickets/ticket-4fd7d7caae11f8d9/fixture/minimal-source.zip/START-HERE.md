Synthetic fixture only.
