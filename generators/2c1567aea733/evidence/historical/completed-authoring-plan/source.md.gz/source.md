# Anchor-Color Parametric Prototype Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: use test-driven development and execute this plan task-by-task.

**Goal:** Build a task-local, non-production prototype for `2c1567aea733` with episode-fixed `anchor_color ∈ {1,2,4}`, canonical default `1`, independently configurable demonstration/query counts, four-query retained evidence, and complete Racket verification.

**Architecture:** Keep the production generator and canonical authority untouched. Reuse lawful copied-shape inputs from the selected generator so any declared anchor can align every color without clipping; derive alternate complete Racket programs by changing only the canonical anchor lookup. Export public challenge bytes through `reviewer_support` so filenames depend only on visible demonstrations and query inputs.

**Tech Stack:** Python 3.12, pytest, bundled Racket bridge, task-local JSON evidence.

**Spec:** `WORK/DUTIES.md`, `WORK/PARAMETRIC-RULES.md`, and the canonical record for task `2c1567aea733`.

## Global Constraints

- Do not modify `generator.py`, the canonical rule hash, shared runtime interfaces, or approval state.
- Declare `anchor_color` allowed values exactly `(1, 2, 4)` and default exactly `1`.
- Select the hidden parameter once per episode from the episode seed; input sampling must not depend on it.
- Default evidence episodes use three demonstrations and four distinct queries.
- Every retained output must be executed by the matching complete Racket program; Python is only an independent mirror.
- Public filenames/IDs hash exact visible bytes and must not encode private parameters, programs, seeds, or query answers.
- Evidence failures must be written honestly as error reports rather than partial passes.

## Review Focus

- Boolean/non-integer seeds or settings are rejected rather than silently coerced.
- All anchor settings preserve every cell on every sampled input; no Racket clipping is hidden.
- Demonstrations refute both alternate anchor settings before any query answer is used.
- Duplicate visible inputs are rejected instead of silently producing weak four-query supervision.
- Re-running into an existing evidence directory fails without overwriting prior proof.

---

### Task 1: Contract tests

**Files:**
- Create: `generators/2c1567aea733/tests/test_parametric_anchor_color.py`
- Create: `generators/2c1567aea733/tests/test_parametric_public_names.py`

**Interfaces:**
- Consumes: selected generator `generate(...)`, `self_check(...)`, canonical task record, `RacketBridge`.
- Produces expected API: `choose_anchor`, `program_for`, `apply_python`, `sample_inputs`, `build_episode`, `public_challenge`, `public_filename`, `score_episode`, `write_evidence`.

- [ ] Write tests for strict parameter/seed/count validation and deterministic episode-level selection.
- [ ] Write tests that default Racket source equals the canonical program byte-for-byte and alternatives change only `(find-color g 1)`.
- [ ] Write tests for canonical default labels, same-input divergence across all three settings, cell preservation, and no clipping.
- [ ] Write tests for three-demo/four-query episodes, distinct visible inputs, input independence from setting, and demonstration-only refutation of both rivals for every query.
- [ ] Write tests that public identifiers ignore metadata and hidden/query labels but change with visible bytes.
- [ ] Write an evidence-writer test covering all three Racket programs, canonical checks, 21 episode labels, public/private separation, manifest hashes, and honest failure output.
- [ ] Run the focused tests and confirm they fail because the prototype does not yet exist.

### Task 2: Prototype and exporter

**Files:**
- Create: `generators/2c1567aea733/workspace/parametric/prototype.py`
- Create: `generators/2c1567aea733/workspace/parametric/README.md`

**Interfaces:**
- `choose_anchor(seed: int) -> int`
- `program_for(anchor_color: int = 1, *, root: Path | str = ROOT) -> str`
- `apply_python(grid: list[list[int]], anchor_color: int = 1) -> list[list[int]]`
- `sample_inputs(seed: int, *, pair_count: int = 7, root=ROOT) -> tuple[list[list[int]], ...]`
- `build_episode(seed: int, *, anchor_color: int | None = None, demo_count: int = 3, query_count: int = 4, root=ROOT) -> dict`
- `public_challenge(episode: dict) -> dict`
- `public_filename(episode: dict) -> str`
- `score_episode(episode: dict) -> dict`
- `write_evidence(out: Path | str, *, seeds=(0,1,2), demo_count=3, query_count=4, root=ROOT, racket_path=None) -> dict`

- [ ] Implement strict validators and exact complete Racket source selection.
- [ ] Implement the independent Python mirror with palette, geometry, collision, and clipping checks.
- [ ] Implement deterministic copied-shape sampling with uniqueness/retry bounds independent of the selected anchor.
- [ ] Implement episode construction, public projection, opaque public names, and demonstration-only rival scoring.
- [ ] Implement fail-closed Racket evidence materialization with canonical checks, cross-setting witness, reports, and manifest.
- [ ] Add the exact four-query command and scope/limits to the README.
- [ ] Run focused tests until green; then run unchanged canonical task tests as a regression check.

### Task 3: Retained proof and handoff

**Files:**
- Modify: `generators/2c1567aea733/notes.md`
- Create: `../checks/parametric/2c1567aea733-anchor-color-v1/`
- Modify: `../RESULTS.json`
- Create: `../REVIEW.md`

- [ ] Run the evidence writer through `review.py run` into a fresh check directory.
- [ ] Inspect report, manifest, public files, and a same-input witness; run a bounded adversarial pass over retry/duplicate boundaries and public/private IDs.
- [ ] Record exact commands, hashes, statuses, and limits in `RESULTS.json`; update concise task notes and `REVIEW.md` without claiming production approval.
- [ ] Run assigned supplementary tickets, package the validated delta ZIP, and verify its contents.
